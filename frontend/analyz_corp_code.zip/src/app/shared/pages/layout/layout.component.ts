import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MenuComponent } from "../../components/menu/menu.component";
import { HeaderComponent } from "../../components/header/header.component";
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-shared-layout',
  imports: [RouterOutlet, MenuComponent, HeaderComponent, NgIf],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent {
  showMenu = true;

  toggleMenuVisibility() {
    this.showMenu = !this.showMenu;
  }
}
